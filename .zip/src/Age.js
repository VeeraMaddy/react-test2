import React from "react";
import ReactDOM from "react-dom";
import { Multiselect } from "multiselect-react-dropdown";

export default class Age extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      plainArray: ["Option 1", "Option 2", "Option 3", "Option 4", "Option 5"],
      objectArray: [
        { key: "Option 1", cat: "Below 25" },
        { key: "Option 2", cat: "25-40" },
        { key: "Option 3", cat: "Above 40" }
      ],
      selectedValues: []
    };
    this.style = {
      chips: {
        background: "red"
      },
      searchBox: {
        border: "none",
        "border-bottom": "1px solid blue",
        "border-radius": "0px"
      }
    };
  }
  render() {
    const { plainArray, objectArray, selectedValues } = this.state;
    return (
      <div className="App">
        <div className="col-12 d-md-flex">
          <div className="col-12 col-md-4 mt20 contents">
            <h2 className="mb20">Contents</h2>
            <a href="https://codesandbox.io/s/10xn41w767">
              1. Demo Source Code
            </a>
            <a href="#flat">2. Flat Array</a>
            <a href="#objects">3. Array of Objects</a>
            <a href="#pre">4. Preselected Values</a>
            <a href="#disable">5. Disable Preselected Values</a>
            <a href="#checkbox">6. Checkbox</a>
            <a href="#group">7. Grouping Objects</a>
            <a href="#limit">8. Selection Limit</a>
            <a href="#placeholder">9. Custom Placeholder</a>
            <a href="#css">10. CSS Customization</a>
            <a href="#icons">11. Close Icons</a>
          </div>
          <div className="examples col-12 col-md-5">
            <h4 className="mt20" id="flat">
              1. Multiselect with flat array
            </h4>
            <Multiselect options={plainArray} isObject={false} />
            <h4 id="pre" className="mt40">
              3. Multiselect with preselect values
            </h4>
            <Multiselect
              options={objectArray}
              displayValue="key"
              selectedValues={selectedValues}
            />
            <h4 id="disable" className="mt40">
              4. Disable preselected values
            </h4>
            <Multiselect
              options={objectArray}
              displayValue="key"
              disablePreSelectedValues={true}
              selectedValues={selectedValues}
            />
            <h4 id="checkbox" className="mt40">
              5. Multiselect with checkbox
            </h4>
            <Multiselect
              options={objectArray}
              displayValue="key"
              showCheckbox={true}
            />
            <h4 id="group" className="mt40">
              6. Multiselect with grouping
            </h4>
            <Multiselect
              options={objectArray}
              displayValue="key"
              groupBy="cat"
              showCheckbox={true}
            />
            <h4 id="limit" className="mt40">
              7. Multiselect with selection limit <small>Ex:2</small>
            </h4>
            <Multiselect
              options={objectArray}
              displayValue="key"
              selectionLimit="2"
            />
            <h4 id="placeholder" className="mt40">
              8. Custom placeholder
            </h4>
            <Multiselect
              placeholder="Custom Placeholder"
              options={objectArray}
              displayValue="key"
            />
            <h4 className="mt40" id="css">
              9. CSS Customization
            </h4>
            <Multiselect
              options={objectArray}
              displayValue="key"
              style={this.style}
            />
            <h4 id="icons" className="mt40">
              10. Close Icons{" "}
              <small className="otheroptions">
                <a href="https://github.com/srigar/multiselect-react-dropdown#6-close-icons">
                  Click to check Close Icon options
                </a>
              </small>
            </h4>
            <Multiselect
              options={objectArray}
              closeIcon="close"
              displayValue="key"
              selectedValues={selectedValues}
            />
          </div>
        </div>
      </div>
    );
  }
}
